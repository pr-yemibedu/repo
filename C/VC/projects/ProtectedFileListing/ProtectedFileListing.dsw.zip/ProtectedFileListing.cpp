// ProtectedFileListing.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "ProtectedFileListing.h"
#include "C:\Program Files\Microsoft Platform SDK\Include\sfc.h"
#include <list>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// The one and only application object

CWinApp theApp;

using namespace std;

// helper functions
void DisplayArrayOfChars(WCHAR* chArray);
void DisplayFileList(list<WCHAR*> &l);

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;
	list<WCHAR*> l;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		cerr << _T("Fatal Error: MFC initialization failed") << endl;
		nRetCode = 1;
	}
	else
	{
		// TODO: code your application's behavior here.
		CString strHello;
		strHello.LoadString(IDS_HELLO);
		cout << (LPCTSTR)strHello << endl;

		PROTECTED_FILE_DATA pfd;
		memset(&pfd, 0, sizeof(PROTECTED_FILE_DATA));

		pfd.FileNumber = 0;

		do
		{
			if ((SfcGetNextProtectedFile(NULL, &pfd)) != 0)
			{
				DisplayArrayOfChars(pfd.FileName);
				// l.push_back((WCHAR*) pfd.FileName);
				cout << endl;
			}

		}while (GetLastError() != ERROR_NO_MORE_FILES);
	}

	// DisplayFileList(l);

	return nRetCode;
}

void DisplayArrayOfChars(WCHAR* chArray)
{
	int i = 0;

	for (;;)
	{
		if (chArray[i] != '\0')
		{
			cout << (char) chArray[i];
		}

		else
		{
			break;
		}

		i++;
	}
}

void DisplayFileList(list<WCHAR*> &l)
{
	WCHAR* wch;

	memset(wch, 0, sizeof(WCHAR));

	while (l.size() > 0)
	{
		wch = l.front();
		DisplayArrayOfChars(wch);
		cout << endl;
		l.pop_front();
	}
}


